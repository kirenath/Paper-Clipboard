import { cookies } from "next/headers"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/lib/session"

// Development fallback password.
// IMPORTANT: this must NOT be used in production. Always set APP_PASSWORD.
const DEV_FALLBACK_PASSWORD = "dev-password"

export function getAppPassword(): string {
  return process.env.APP_PASSWORD || DEV_FALLBACK_PASSWORD
}

export function isUsingDevFallback(): boolean {
  return !process.env.APP_PASSWORD
}

export async function getSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  return verifySessionToken(token)
}

export async function isAuthenticated(): Promise<boolean> {
  const session = await getSession()
  return session !== null
}
